<?php
session_start();
// added in v4.0.0
require_once 'autoload.php';
use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\Entities\AccessToken;
use Facebook\HttpClients\FacebookCurlHttpClient;
use Facebook\HttpClients\FacebookHttpable;
// init app with app id and secret
FacebookSession::setDefaultApplication( '1471382046511077','8aaff4e6106421dba5625f09115107cd' );
// login helper with redirect_uri
    $helper = new FacebookRedirectLoginHelper('http://fnd.acrosslimits.com/php/Facebook/fbconfig.php' );
try {
  $session = $helper->getSessionFromRedirect();
} catch( FacebookRequestException $ex ) {
  // When Facebook returns an error
} catch( Exception $ex ) {
  // When validation fails or other local issues
}
// see if we have a session
if ( isset( $session ) ) {
  // graph api request for user data
  $request = new FacebookRequest( $session, 'GET', '/me' );
  
  $response = $request->execute();
  
  // get response
  $graphObject = $response->getGraphObject();
     	$fbid = $graphObject->getProperty('id');              // To Get Facebook ID
 	    $fbfullname = $graphObject->getProperty('name'); // To Get Facebook full name
        $fbfirstname = $graphObject->getProperty('first_name');
        $fblastname = $graphObject->getProperty('last_name');
	    $femail = $graphObject->getProperty('email');    // To Get Facebook email ID
        $fbgender = $graphObject->getProperty('gender');
        $fbbirthday = $graphObject->getProperty('birthday');
        $fbcounry = $graphObject->getProperty('location');
	/* ---- Session Variables -----*/
	    $_SESSION['FBID'] = $fbid;           
        $_SESSION['FIRSTNAME'] = $fbfirstname;
        $_SESSION['LASTNAME'] = $fblastname;
	    $_SESSION['EMAIL'] =  $femail;
        $_SESSION['GENDER'] =  $fbgender;
        $_SESSION['BIRTHDAY'] =  $fbbirthday;
        $_SESSION['COUNTRY'] =  $fbcountry;
    /* ---- header location after session ----*/
  header("Location: index.php");
} else {
  $loginUrl = $helper->getLoginUrl();
 header("Location: ".$loginUrl);
}
?>