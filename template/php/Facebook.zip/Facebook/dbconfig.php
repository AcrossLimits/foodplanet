<?php
define('DB_SERVER', '148.251.84.234');
define('DB_USERNAME', 'acrosslimits');    // DB username
define('DB_PASSWORD', 'wra8ap@EdE*');    // DB password
define('DB_DATABASE', 'fnd');      // DB name
$connection = mysql_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD) or die( "Unable to connect");
$database = mysql_select_db(DB_DATABASE) or die( "Unable to select database");
?>